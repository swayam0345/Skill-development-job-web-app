
<?php
 $id=$_COOKIE['id'];
  $db = mysqli_connect("localhost", "root", "", "group");
  
 
   if (isset($_POST['create'])){
	   $tb=$_POST['uname'];
       $desc=$_POST['description'];
	   
       $sql1="INSERT INTO groups (name,description,uid) VALUES ('$tb','$desc','$id')";
	   mysqli_query($db, $sql1);
	   $sql2="INSERT INTO groups1 (name,description,uid) VALUES ('$tb','$desc','$id')";
       mysqli_query($db, $sql2);
   }
   $query="SELECT * FROM groups";
   $results2=mysqli_query($db,$query);
   
	   
   
  

   

?>





<html>
<head>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" integrity="sha512-K1qjQ+NcF2TYO/eI3M6v8EiNYZfA95pQumfvcVrTHtwQVDG+aHRqLi/ETn2uB+1JqwYqVG3LIvdm9lj6imS/pQ==" crossorigin="anonymous"></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   
	
      <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
	<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover {
    opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 0 0 0 0;
    position: relative;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
	width:600px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 50%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}

/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
.topnav {
  overflow: hidden;
  background-color: #f1f1f1;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
  border-bottom: 3px solid transparent;
}



.topnav a.active {
  border-bottom: 3px solid #26547C;
}
</style>
	<body>
	<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;margin-left:700px;margin-right:auto;">Create Group</button>

<div id="id01" class="modal">
  
  <form class="modal-content animate" enctype="multipart/form-data" action="groups.php" method="post">
    <div class="imgcontainer">
	<div style="background-color:#f5f6f7;">
	<h2 style="background-color:#f5f6f7;font-family:Roboto;margin-top:0px;">Create New group</h2></div>
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="1eng/people-group-logo-template_1061-97.jpg" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="uname"><b>Group Name</b></label>
      <input type="text" placeholder="Enter GroupName" name="uname" required>
	  <input type="text" placeholder="Enter Description" name="description" required>
        
      <button type="submit" name="create">Create</button>

    </div>


  </form>
</div>
<div class="topnav" style="padding:5px;" id="tabs">
  <a class="active" href="groups" >Your Groups</a>
  <a  href="groups1" >New Groups</a>

</div>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
<script>
function myFunction() {
    var x = document.getElementById("card1");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
function myFunction1() {
    var x = document.getElementById("card2");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
</script><script>
  $( function() {
    $( "#tabs" ).tabs();
  } );
</script>
<script>
$(document).ready(function(){
	$('#search').keyup(function(){
		var search = $('#search').val();
	$.ajax({
		url:'search.php',
		data:{search:search},
		type:'POST',
		sucess:function(data){
			if(!data.error){
				$('#content2').html(data);
	}}});
});});
</script>

<br><br>


  
  <br>

   <div class="card-deck" id="content">
<div class="flex-container">
 <?php

	 
 $cook=$_COOKIE['id'];

 while ($row = mysqli_fetch_array($results2)) {
	 $me=$row['id'];
	 $cook=$_COOKIE['id'];
      echo "<div>";
      echo "<div class='card' id='crd'>";
	  
      	echo "<a href='groupinfo.php?join=$me'><img class='card-img-top' src='group.png' alt='Card image cap'></a>";
		echo "<div class='card-body'>";
      	echo " <h5 class='card-title'>".$row['name']."</h5>";
		echo " <h5 class='card-title'>".$row['description']."</h5>";
        echo "<a href='joingroup.php?join=$me'><input type='button' class='btn btn-primary' value='join'></input></a>";
	
	echo "</div>";
    echo "</div>";
	echo "<br><br>";

	 
	  

    }
	

  ?>
  </div></div>
  <div id="content2"></div>

<script src="general.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


   

</body></html>